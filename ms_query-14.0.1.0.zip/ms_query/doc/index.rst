=======================
Execute Query From Odoo
=======================

Installation
============
`Install <https://blog.miftahussalam.com/install-apps-odoo/>`__ this module in a usual way

Configuration
=============
`Activate Developer Mode <https://youtu.be/wLzlq3qH1Cc>`__

Usage
=====
* Go to ``Settings >> Technical >> Execute Query``
* Type query on ``Syntax query`` column
* Click ``Execute`` button
* RESULT: See result on ``Result`` column

Uninstallation
==============
Uninstall this module in a usual way